package model

data class Faq(
    val faqQue:String,
    val faqAns:String
)