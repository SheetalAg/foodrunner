package model

data class Food (
    val id:Int,
    val name:String,
    val cost_for_one:String

)