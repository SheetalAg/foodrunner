package adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sheetal.highersolution.R
import model.Faq

class FaqsRecyclerAdapter(val context: Context, val itemList:ArrayList<Faq>) :RecyclerView.Adapter<FaqsRecyclerAdapter.FaqsViewHolder>(){


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FaqsViewHolder {
        val view=LayoutInflater.from(parent.context).inflate(R.layout.recyclerfaqs,parent,false)
        return FaqsViewHolder(view)
    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    override fun onBindViewHolder(holder: FaqsViewHolder, position: Int) {

        val faq=itemList[position]
        holder.textViewque.text=faq.faqQue
        holder.textViewans.text=faq.faqAns
    }
    class FaqsViewHolder(view:View):RecyclerView.ViewHolder(view)
    {

        val textViewque:TextView=view.findViewById(R.id.txtque)
        val textViewans:TextView=view.findViewById(R.id.txtans)
    }

}
