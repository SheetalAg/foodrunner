package adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.RecyclerView
import com.sheetal.highersolution.R
import model.Food

class RestaurantDetailsAdapter(val context: Context, val foodList:ArrayList<Food>, val listner: OnItemClickListener):RecyclerView.Adapter<RestaurantDetailsAdapter.RecyclerViewHolder>() {
companion object{
    var isCartEmpty=true
}
    class RecyclerViewHolder(view: View):RecyclerView.ViewHolder(view) {
        val txtsno: TextView =view.findViewById(R.id.txtsno)
        val txtResName: TextView =view.findViewById(R.id.txtResName)
        val txtCost: TextView =view.findViewById(R.id.txtCost)
        val btnRestaurantAdd:Button=view.findViewById(R.id.btnRestaurantAdd)
        val btnRemove:Button=view.findViewById(R.id.btnRemove)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RestaurantDetailsAdapter.RecyclerViewHolder {
        val view= LayoutInflater.from(parent.context).inflate(R.layout.recyclerdetails,parent, false)
        return RestaurantDetailsAdapter.RecyclerViewHolder(view)
    }
    override fun getItemCount(): Int {
        return foodList.size
    }
    interface OnItemClickListener
    {
        fun onAddItemClick(food: Food)
        fun onRemoveItemClick(food: Food)
    }
    override fun onBindViewHolder(holder: RecyclerViewHolder, position: Int) {
        val resfood = foodList[position]
        holder.txtResName.text = resfood.name
        holder.txtCost.text = resfood.cost_for_one
        holder.txtsno.text = (position +1).toString()
        holder.btnRestaurantAdd.setOnClickListener {
            holder.btnRestaurantAdd.visibility=View.GONE
            holder.btnRemove.visibility=View.VISIBLE
            listner.onAddItemClick(resfood)
            Toast.makeText(context,"${resfood.name} is added to cart!!",Toast.LENGTH_SHORT).show()
        }
        holder.btnRemove.setOnClickListener {
            holder.btnRemove.visibility=View.GONE
            holder.btnRestaurantAdd.visibility=View.VISIBLE
            listner.onRemoveItemClick(resfood)
            Toast.makeText(context,"${resfood.name} is removed from the cart!!",Toast.LENGTH_SHORT).show()
        }
    }

    override fun getItemViewType(position: Int): Int {
        return super.getItemViewType(position)
    }
}