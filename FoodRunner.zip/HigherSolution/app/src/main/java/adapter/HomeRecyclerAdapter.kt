package adapter

import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.sheetal.highersolution.R
import com.squareup.picasso.Picasso
import database.Entities
import database.RestaurantDatabase
import fragment.RestaurantDetailFragment
import model.Restaurants

class HomeRecyclerAdapter(val context: Context,val itemList: ArrayList<Restaurants>): RecyclerView.Adapter<HomeRecyclerAdapter.HomeViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HomeViewHolder {
        val view=LayoutInflater.from(parent.context).inflate(R.layout.recyclerhome,parent, false)
        return HomeViewHolder(view)
    }
    override fun getItemCount(): Int {
        return itemList.size
    }
    override fun onBindViewHolder(holder: HomeViewHolder, position: Int) {
        val restaurants=itemList[position]
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            holder.imgRestaurantsImage.clipToOutline = true
        }
        holder.txtRestaurantsName.text= restaurants.name
        holder.txtRating.text=restaurants.rating
        val costForOne="${restaurants.costForOne.toString()}/Person"
        holder.txtPrice.text=costForOne

        //holder.imgRestaurantsImage.setImageResource(restaurants.restaurantImage)
        Picasso.get().load(restaurants.imageUrl).error(R.drawable.rgpv).into(holder.imgRestaurantsImage)
        val listOfFavourites = GetAllFavAsyncTask(context).execute().get()
        if (listOfFavourites.isNotEmpty() && listOfFavourites.contains(restaurants.id.toString())) {
            holder.txtRestaurantsFav.setImageResource(R.drawable.ic_fav_icon_checked)
        } else {
            holder.txtRestaurantsFav.setImageResource(R.drawable.ic_fav_icon)
        }
        holder.txtRestaurantsFav.setOnClickListener {
            val restaurantEntity = Entities(
                restaurants.id,
                restaurants.name,
                restaurants.rating,
                restaurants.costForOne.toString(),
                restaurants.imageUrl)
            if (!DBAsyncTask(context, restaurantEntity, 1).execute().get()) {
                val async = DBAsyncTask(context, restaurantEntity, 2).execute()
                val result = async.get()
                if (result) {
                    holder.txtRestaurantsFav.setImageResource(R.drawable.ic_fav_icon_checked)
                }
            } else {
                val async = DBAsyncTask(context, restaurantEntity, 3).execute()
                val result = async.get()
                if (result) {
                    holder.txtRestaurantsFav.setImageResource(R.drawable.ic_fav_icon)
                }
            }
        }

        holder.cardRestaurant.setOnClickListener {
            val fragment=RestaurantDetailFragment()
            val args=Bundle()
            args.putInt("id",restaurants.id as Int)
            args.putString("name",restaurants.name)
            fragment.arguments=args
            val transaction=(context as FragmentActivity).supportFragmentManager.beginTransaction()
            transaction.replace(R.id.frame,fragment)
            transaction.commit()
            (context as AppCompatActivity).supportActionBar?.title=holder.txtRestaurantsName.text.toString()
        }
    }
    class HomeViewHolder(view: View):RecyclerView.ViewHolder(view)
    {
        val txtRestaurantsName:TextView=view.findViewById(R.id.txtRestaurantsName)
        val txtRestaurantsFav:ImageView=view.findViewById(R.id.txtRestaurantsFav)
        val txtPrice:TextView=view.findViewById(R.id.txtPrice)
        val txtRating:TextView=view.findViewById(R.id.txtRating)
        val imgRestaurantsImage:ImageView=view.findViewById(R.id.imgRestaurantsImage)
        val cardRestaurant:CardView=view.findViewById(R.id.cardRestaurant)

    }
    class DBAsyncTask(val context: Context, val restaurantEntity: Entities, val mode:Int):
        AsyncTask<Void, Void, Boolean>()
    {
        val db= Room.databaseBuilder(context, RestaurantDatabase::class.java,"restaurant-db").build()
        override fun doInBackground(vararg p0: Void?): Boolean {
            when(mode)
            {
                1->
                {
                    val restaurant: Entities?=db.restaurantDao().getRestaurantById(restaurantEntity.id.toString())
                    db.close()
                    return restaurant!=null
                }
                2->
                {
                    db.restaurantDao().insertRestaurant(restaurantEntity)
                    db.close()
                    return true
                }
                3->
                {
                    db.restaurantDao().deleteRestaurant(restaurantEntity)
                    db.close()
                    return true
                }
            }
            return false
        }
    }
    class GetAllFavAsyncTask(
        context: Context
    ) : AsyncTask<Void, Void, List<String>>() {
        val db = Room.databaseBuilder(context, RestaurantDatabase::class.java, "restaurant-db").build()
        override fun doInBackground(vararg params: Void?): List<String> {
            val list = db.restaurantDao().getAllRestaurants()
            val listOfIds = arrayListOf<String>()
            for (i in list) {
                listOfIds.add(i.id.toString())
            }
            return listOfIds
        }
    }
}