package fragment

import adapter.HomeRecyclerAdapter
import android.content.Context
import android.os.AsyncTask
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.sheetal.highersolution.R
import database.Entities
import database.RestaurantDatabase
import model.Restaurants


class FavoriteFragment : Fragment() {

lateinit var rlnofav:RelativeLayout
    lateinit var favrecycler:RecyclerView
    lateinit var rlfav:RelativeLayout
    lateinit var imgfav:ImageView
    lateinit var txtfav:TextView
    lateinit var favRelpro:RelativeLayout
    lateinit var favProgress:ProgressBar
    lateinit var HomeRecyclerAdapter:HomeRecyclerAdapter
    private var restaurantInfoList = arrayListOf<Restaurants>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view= inflater.inflate(R.layout.fragment_favorite, container, false)
        rlnofav=view.findViewById(R.id.rlnofav)
        rlfav=view.findViewById(R.id.rlfav)
        favRelpro=view.findViewById(R.id.favRelpro)
        favRelpro.visibility=View.VISIBLE
        setUpRecycler(view)


        return view
    }
    private fun setUpRecycler(view: View)
    {
        favrecycler=view.findViewById(R.id.favrecycler)
        val backgroundList=FavouritesAsync(activity as Context).execute().get()
        if(backgroundList.isEmpty())
        {
            favRelpro.visibility = View.GONE
            rlfav.visibility = View.GONE
            rlnofav.visibility = View.VISIBLE
        } else {
            rlfav.visibility = View.VISIBLE
            favRelpro.visibility = View.GONE
            rlnofav.visibility = View.GONE
            for (i in backgroundList) {
                restaurantInfoList.add(
                    Restaurants(
                        i.id,
                        i.name,
                        i.rating,
                        i.cost_for_one.toInt(),
                        i.image_url
                    )
                )
            }

            HomeRecyclerAdapter = HomeRecyclerAdapter( activity as Context,restaurantInfoList)
            val mLayoutManager = LinearLayoutManager(activity)
            favrecycler.layoutManager = mLayoutManager
            favrecycler.itemAnimator = DefaultItemAnimator()
            favrecycler.adapter = HomeRecyclerAdapter
            favrecycler.setHasFixedSize(true)
        }

    }


    /*A new async class for fetching the data from the DB*/
    class FavouritesAsync(context: Context) : AsyncTask<Void, Void, List<Entities>>() {

        val db = Room.databaseBuilder(context, RestaurantDatabase::class.java, "restaurant-db").build()

        override fun doInBackground(vararg params: Void?): List<Entities> {

            return db.restaurantDao().getAllRestaurants()
        }


    }

}

