package fragment

import adapter.FaqsRecyclerAdapter
import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sheetal.highersolution.R
import model.Faq


class FaqsFragment : Fragment() {
    lateinit var faqprogress:ProgressBar
    lateinit var faqprogresslayout:RelativeLayout
    lateinit var recyclerfaqfragment:RecyclerView
    lateinit var layoutManager:RecyclerView.LayoutManager
    lateinit var faqAdapter:FaqsRecyclerAdapter
    val faqInfoList= arrayListOf<Faq>(
        Faq("Q.1 How will the training be delievered?","A.1 You have already created an account but you can't remember your password? Click on 'Login/SignUp' at the top of the page.Then click on 'Forgot Password?'. Fill out your phone number and a password recovery will be sent to you by phone."),
        Faq("Q.2 What are your delivery hour?","A.2 Our delivery hour is from 10.00 AM to 08:00PM."),
        Faq("Q.3 How much time it takes to delivery?","A.3 Generally it takes between 45 minutes to 1 hour time to deliver the order.Due to long distance or heavy traffic,delivery might takefew extra minutes."),
        Faq("Q.4 How do I know status of my order?","A.4 After you place your order,it is sent immediately to the kitchen,which starts preparaing it without any delay."),
        Faq("Q.5 Do you support bulk order?","A.5 In order to provide all customers with a great selection and to ensure on-time delivery of your meal, we request you to order bulk quantity at least 24 hours in advance."),
        Faq("Q.6 Can i order same item repeatdely at the same time?","A.6 No as of now you can order one item only one time. ")

    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view= inflater.inflate(R.layout.fragment_faqs, container, false)
        recyclerfaqfragment=view.findViewById(R.id.Recyclerfaqfragment)
        layoutManager=LinearLayoutManager(activity)
        faqprogress=view.findViewById(R.id.faqprogress)
        faqprogress.visibility=View.VISIBLE
        faqprogresslayout=view.findViewById(R.id.faqprogresslayout)
        faqprogresslayout.visibility=View.VISIBLE
        faqAdapter= FaqsRecyclerAdapter(activity as Context,faqInfoList)
        recyclerfaqfragment.adapter=faqAdapter
        recyclerfaqfragment.layoutManager=layoutManager
        faqprogresslayout.visibility=View.GONE

        return view
    }


}