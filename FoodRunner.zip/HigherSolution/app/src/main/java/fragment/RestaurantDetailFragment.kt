package fragment

import activity.CartActivity
import adapter.RestaurantDetailsAdapter
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.AsyncTask
import android.os.Bundle
import android.provider.Settings
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import com.sheetal.highersolution.R
import database.MenuEntity
import database.RestaurantDatabase
import model.Food
import org.json.JSONException
import util.ConnectionManager
import util.DrawerLocker
class RestaurantDetailFragment : Fragment() {
    lateinit var DetailRecycler: RecyclerView
    lateinit var RProgressLayout: RelativeLayout
    lateinit var RprogressBar: ProgressBar
    lateinit var layoutManager: LinearLayoutManager
    var foodInfoList = arrayListOf<Food>()
    var orderList = arrayListOf<Food>()
    lateinit var recyclerDetailAdapter: RestaurantDetailsAdapter
    lateinit var sharedpreferences: SharedPreferences

    companion object {
        @SuppressLint("StaticFieldLeak")
        lateinit var btnAddcart: Button
        var restaurantId: Int? = 0
        var restaurantName: String? = ""
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_restaurant_detail, container, false)
        RprogressBar = view.findViewById(R.id.RProgressBar)
        RProgressLayout = view.findViewById(R.id.RProgressLayout)
        RProgressLayout.visibility = View.VISIBLE
        //(activity as DrawerLocker).setDrawerEnabled(false)
        setHasOptionsMenu(true)
        btnAddcart = view.findViewById(R.id.btnAddcart)
        btnAddcart.visibility = android.view.View.GONE
        btnAddcart.setOnClickListener {
            println(orderList)
            proceedToCart()
        }
        sharedpreferences = activity?.getSharedPreferences("FoodApp", Context.MODE_PRIVATE) as SharedPreferences
        restaurantId = arguments?.getInt("id", 0)
        restaurantName = arguments?.getString("name", "")
        SetupRMenu(view)
        return view
    }

    private fun SetupRMenu(view: View) {
        DetailRecycler = view.findViewById(R.id.RecyclerDetails)

        // val url = "http://13.235.250.119/v2/restaurants/fetch_result/+restaurantId"
        if (ConnectionManager().checkConnectivity(activity as Context)) {
            val queue = Volley.newRequestQueue(activity as Context)
            val jsonObjectRequest = object : JsonObjectRequest(
                Request.Method.GET,
                "http://13.235.250.119/v2/restaurants/fetch_result/" + restaurantId,
                null,
                Response.Listener { it ->
                    RProgressLayout.visibility = android.view.View.GONE
                    try {
                        val data = it.getJSONObject("data")
                        val success = data.getBoolean("success")
                        if (success) {
                            val foodData = data.getJSONArray("data")
                            for (i in 0 until foodData.length()) {
                                val foodJsonObject = foodData.getJSONObject(i)
                                val food = Food(
                                    foodJsonObject.getString("id").toInt(),
                                    foodJsonObject.getString("name"),
                                    foodJsonObject.getString("cost_for_one")
                                )
                                foodInfoList.add(food)
                                recyclerDetailAdapter =
                                    RestaurantDetailsAdapter(activity as Context, foodInfoList,
                                        object : RestaurantDetailsAdapter.OnItemClickListener {
                                            override fun onAddItemClick(food: Food) {
                                                orderList.add(food)
                                                if (orderList.size > 0) {
                                                    btnAddcart.visibility = View.VISIBLE
                                                    RestaurantDetailsAdapter.isCartEmpty = false
                                                }
                                            }

                                            override fun onRemoveItemClick(food: Food) {
                                                orderList.remove(food)
                                                if (orderList.isEmpty()) {
                                                    btnAddcart.visibility = android.view.View.GONE
                                                    RestaurantDetailsAdapter.isCartEmpty = true
                                                }
                                            }
                                        })
                                layoutManager = LinearLayoutManager(activity)
                                DetailRecycler.adapter = recyclerDetailAdapter
                                DetailRecycler.itemAnimator = DefaultItemAnimator()
                                DetailRecycler.layoutManager = layoutManager
                            }
                        } else {
                        Toast.makeText(activity as Context, "Error", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                },
                Response.ErrorListener {
                    Toast.makeText(
                        activity as Context, "Volley",
                        Toast.LENGTH_SHORT
                    ).show()

                }) {
                override fun getHeaders(): MutableMap<String, String> {
                    val headers = HashMap<String, String>()
                    headers["Content-type"] = "application/json"
                    headers["token"] = "33097804dcdcc2"
                    return headers
                }
            }
            queue.add(jsonObjectRequest)
        } else {
            val dialog = AlertDialog.Builder(activity as Context)
            dialog.setTitle("Error")
            dialog.setMessage("Internet Connection is not found")
            dialog.setPositiveButton("Open Settings") { text, listner ->
                val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingsIntent)
                activity?.finish()
            }
            dialog.setNegativeButton("Cancel") { text, listner ->
                ActivityCompat.finishAffinity(activity as Activity)
            }
            dialog.create()
            dialog.show()
        }
    }
    fun proceedToCart() {
        val gson = Gson()
        val foodItem = gson.toJson(orderList)
        val async = ItemsInCart(activity as Context, restaurantId as Int, foodItem, 1).execute()
        val result = async.get()
        println(foodItem)
        if (result) {
            Toast.makeText(activity, "Cart Page!!", Toast.LENGTH_SHORT).show()
            val data = Bundle()
            data.putInt("resId", RestaurantDetailFragment.restaurantId as Int)
            data.putString("resName", RestaurantDetailFragment.restaurantName)
            println("Error")
            val intent = Intent(activity as Context, CartActivity::class.java)
            intent.putExtra("data", data)
            startActivity(intent)
        } else {
            Toast.makeText(activity as Context, "Some error occurred!!", Toast.LENGTH_SHORT).show()
        }
    }
    class ItemsInCart(
        val context: Context,
        private val resId: Int,
        private val food_item: String,
        val mode: Int
    ) : AsyncTask<Void, Void, Boolean>() {
         val db =
            Room.databaseBuilder(context, RestaurantDatabase::class.java, "restaurant-db").build()

        override fun doInBackground(vararg params: Void?): Boolean {
            when (mode) {
                1 -> {
                    db.menuDao().insertOrder(MenuEntity(resId, food_item))
                    db.close()
                    return true
                }
                2 -> {
                    db.menuDao().deleteOrder(MenuEntity(resId, food_item))
                    db.close()
                    return true
                }
            }
            return false
        }
    }
}





