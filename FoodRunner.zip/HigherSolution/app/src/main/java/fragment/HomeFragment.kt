package fragment

import adapter.HomeRecyclerAdapter
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.sheetal.highersolution.R
import database.Entities
import database.RestaurantDatabase
import model.Restaurants
import org.json.JSONException
import org.json.JSONObject
import util.ConnectionManager
import util.FETCH_RESTAURANTS
import java.util.*
import kotlin.Comparator
import kotlin.collections.HashMap


class HomeFragment : Fragment() {

    lateinit var RecyclerHome:RecyclerView
    lateinit var layoutManager: RecyclerView.LayoutManager
    lateinit var recyclerAdapter: HomeRecyclerAdapter
    lateinit var ProgressLayout:RelativeLayout
    lateinit var ProgressBar:ProgressBar
    val restaurantsInfoList= arrayListOf<Restaurants>()
    var ratingComparator=Comparator<Restaurants> { restaurants1, restaurants2 ->
        if (restaurants1.rating.compareTo(restaurants2.rating, true) == 0) {
            restaurants1.name.compareTo(restaurants2.name, true)
        } else {
restaurants1.rating.compareTo(restaurants2.rating,true)
        }
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view= inflater.inflate(R.layout.fragment_home, container, false)
        setHasOptionsMenu(true)
        RecyclerHome=view.findViewById(R.id.RecyclerHome)
        layoutManager=LinearLayoutManager(activity)
        ProgressLayout=view.findViewById(R.id.ProgressLayout)
        ProgressBar=view.findViewById(R.id.ProgressBar)
        ProgressLayout.visibility=View.VISIBLE


        val queue= Volley.newRequestQueue(activity as Context)
        val url="http://13.235.250.119/v2/restaurants/fetch_result/"
        if(ConnectionManager().checkConnectivity(activity as Context)) {
            val jsonObjectRequest=object : JsonObjectRequest(Request.Method.GET,
                FETCH_RESTAURANTS,null,Response.Listener<JSONObject> { response->
                ProgressLayout.visibility=View.GONE
                try {
                    val data=response.getJSONObject("data")
                    val success=data.getBoolean("success")
                    if(success)
                    {
                        val resArray=data.getJSONArray("data")
                        for(i in 0 until resArray.length())
                        {
                            val restaurantJsonObject=resArray.getJSONObject(i)
                            val restaurantObject=Restaurants(
                                restaurantJsonObject.getString("id").toInt(),
                                restaurantJsonObject.getString("name"),
                                restaurantJsonObject.getString("rating"),
                                restaurantJsonObject.getString("cost_for_one").toInt(),
                                restaurantJsonObject.getString("image_url")
                            )
                            restaurantsInfoList.add(restaurantObject)
                            recyclerAdapter= HomeRecyclerAdapter(activity as Context,restaurantsInfoList)
                            RecyclerHome.adapter=recyclerAdapter
                            RecyclerHome.layoutManager=layoutManager
                        }
                    }
                    else
                    {
                        Toast.makeText(activity as Context,"Error",Toast.LENGTH_SHORT).show()
                    }
                }
               catch (e: JSONException){
                    Toast.makeText(context,"Some Unexpected Exception Occured",Toast.LENGTH_SHORT).show()
                }

            },
                Response.ErrorListener {
                    Toast.makeText(activity as Context,"Volley Error Occured",Toast.LENGTH_SHORT).show()
                })


            {
                override fun getHeaders():MutableMap<String,String>{
                    val headers=HashMap<String,String>()
                    headers["Content-type"]="application/json"
                    headers["token"]="33097804dcdcc2"
                    return headers
                }
            }
            queue.add(jsonObjectRequest)
        }
        else
        {
            val dialog=AlertDialog.Builder(activity as Context)
            dialog.setTitle("Error")
            dialog.setMessage("Internet Connection is not found")
            dialog.setPositiveButton("Open Settings"){
                text,listner->
                val settingsIntent= Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingsIntent)
                activity?.finish()
            }
            dialog.setNegativeButton("Cancel"){
                text,listner->
                ActivityCompat.finishAffinity(activity as Activity)
            }
            dialog.create()
            dialog.show()
        }
        return view
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater?.inflate(R.menu.home_sort,menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id=item?.itemId
        if(id==R.id.sort)
        {
            Collections.sort(restaurantsInfoList,ratingComparator)
            restaurantsInfoList.reverse()
        }
        recyclerAdapter.notifyDataSetChanged()
        return super.onOptionsItemSelected(item)
    }

}