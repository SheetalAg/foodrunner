package util

interface DrawerLocker {

        fun setDrawerEnabled(enabled: Boolean)


}