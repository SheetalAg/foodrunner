package activity

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.widget.Toolbar
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.sheetal.highersolution.R
import model.SessionManager
import org.json.JSONObject
import util.ConnectionManager
import util.REGISTER
import util.Validations


class RegisterActivity : AppCompatActivity() {
    lateinit var registerToolbar:Toolbar
    lateinit var etrName:EditText
    lateinit var etrEmail:EditText
    lateinit var etrmob:EditText
    lateinit var etradd:EditText
    lateinit var etrpass:EditText
    lateinit var etrConfirmpass:EditText
    lateinit var btnRegister:Button
    lateinit var sharedPreferences: SharedPreferences
    lateinit var registerRelative:RelativeLayout
   lateinit var sessionManager: SessionManager
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
     registerToolbar=findViewById(R.id.registerToolbar)
     setSupportActionBar(registerToolbar)
     supportActionBar?.title="Register Yourself"
     supportActionBar?.setHomeButtonEnabled(true)
     registerToolbar.setTitleTextAppearance(this,R.style.PoppinsTextAppearance)
     sessionManager=SessionManager(this@RegisterActivity)
        sharedPreferences=this@RegisterActivity.getSharedPreferences(sessionManager.PREF_NAME,sessionManager.PRIVATE_MODE)
        etrName=findViewById(R.id.etrName)
     etrEmail=findViewById(R.id.etrEmail)
     etrmob=findViewById(R.id.etrmob)
        etradd=findViewById(R.id.etradd)
        etrpass=findViewById(R.id.etrpass)
        etrConfirmpass=findViewById(R.id.etrConfirmpass)
        btnRegister=findViewById(R.id.btnRegister)
        registerRelative=findViewById(R.id.registerRelative)
        registerRelative.visibility= View.VISIBLE
        btnRegister.setOnClickListener {
            registerRelative.visibility = View.INVISIBLE
           // progressBar.visibility = View.VISIBLE
            if (Validations.validateNameLength(etrName.text.toString())) {
                etrName.error = null
                if (Validations.validateEmail(etrEmail.text.toString())) {
                    etrEmail.error = null
                    if (Validations.validateMobile(etrmob.text.toString())) {
                        etrmob.error = null
                        if (Validations.validatePasswordLength(etrpass.text.toString())) { etrpass.error = null
                            if (Validations.matchPassword(etrpass.text.toString(), etrConfirmpass.text.toString())
                            ) {
                                etrpass.error = null
                                etrConfirmpass.error = null
                                if (ConnectionManager().checkConnectivity(this@RegisterActivity)) {
                                    sendRegisterRequest(
                                        etrName.text.toString(),
                                        etrmob.text.toString(),
                                        etradd.text.toString(),
                                        etrpass.text.toString(),
                                        etrEmail.text.toString())
                                } else {
                                    registerRelative.visibility = View.VISIBLE
                                   // progressBar.visibility = View.INVISIBLE
                                    Toast.makeText(this@RegisterActivity, "No Internet Connection", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                registerRelative.visibility = View.VISIBLE
                               // progressBar.visibility = View.INVISIBLE
                                etrpass.error = "Passwords don't match"
                                etrConfirmpass.error = "Passwords don't match"
                                Toast.makeText(this@RegisterActivity, "Passwords don't match", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            registerRelative.visibility = View.VISIBLE
                          //  progressBar.visibility = View.INVISIBLE
                            etrpass.error = "Password should be more than or equal 4 digits"
                            Toast.makeText(this@RegisterActivity, "Password should be more than or equal 4 digits", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        registerRelative.visibility = View.VISIBLE
                       // progressBar.visibility = View.INVISIBLE
                        etrmob.error = "Invalid Mobile number"
                        Toast.makeText(this@RegisterActivity, "Invalid Mobile number", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    registerRelative.visibility = View.VISIBLE
                   // progressBar.visibility = View.INVISIBLE
                    etrEmail.error = "Invalid Email"
                    Toast.makeText(this@RegisterActivity, "Invalid Email", Toast.LENGTH_SHORT).show()
                }
            } else {
                registerRelative.visibility = View.VISIBLE
               // progressBar.visibility = View.INVISIBLE
                etrName.error = "Invalid Name"
                Toast.makeText(this@RegisterActivity, "Invalid Name", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun sendRegisterRequest(name: String, phone: String, address: String, password: String, email: String) {
        val queue = Volley.newRequestQueue(this)
        val jsonParams = JSONObject()
        jsonParams.put("name", name)
        jsonParams.put("mobile_number", phone)
        jsonParams.put("password", password)
        jsonParams.put("address", address)
        jsonParams.put("email", email)
        val jsonObjectRequest = object : JsonObjectRequest(Request.Method.POST, REGISTER, jsonParams, Response.Listener {
                try {
                    val data = it.getJSONObject("data")
                    val success = data.getBoolean("success")
                    if (success) {
                        val response = data.getJSONObject("data")
                        sharedPreferences.edit().putString("user_id", response.getString("user_id")).apply()
                        sharedPreferences.edit().putString("user_name", response.getString("name")).apply()
                        sharedPreferences.edit().putString("user_mobile_number", response.getString("mobile_number")).apply()
                        sharedPreferences.edit().putString("user_address", response.getString("address")).apply()
                        sharedPreferences.edit().putString("user_email", response.getString("email")).apply()
                        sessionManager.setLogin(true)
                        startActivity(Intent(this@RegisterActivity, MainActivity::class.java))
                        finish()
                    } else {
                        registerRelative.visibility = View.VISIBLE
                      //  progressBar.visibility = View.INVISIBLE
                        val errorMessage = data.getString("errorMessage")
                        Toast.makeText(this@RegisterActivity, errorMessage, Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception){
                    registerRelative.visibility = View.VISIBLE
                  //  progressBar.visibility = View.INVISIBLE
                    e.printStackTrace()
                }
            },
            Response.ErrorListener {
                Toast.makeText(this@RegisterActivity, it.message, Toast.LENGTH_SHORT).show()
                registerRelative.visibility = View.VISIBLE
               // progressBar.visibility = View.INVISIBLE
            }
        ){
            override fun getHeaders(): MutableMap<String, String> {
                val headers = HashMap<String, String>()
                headers["Content-type"] = "application/json"
                headers["token"] = "33097804dcdcc2"
                return headers
            }
        }
        queue.add(jsonObjectRequest)
    }
    override fun onSupportNavigateUp(): Boolean {
        Volley.newRequestQueue(this).cancelAll(this::class.java.simpleName)
        onBackPressed()
        return true
    }

}


