package database
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="restaurants")
data class Entities(
    @PrimaryKey() val id:Int,
    @ColumnInfo(name="restaurant_name") val name:String,
    @ColumnInfo(name = "restaurant_rating") val rating:String,
    @ColumnInfo(name = "restaurant_cost") val cost_for_one:String,
    @ColumnInfo(name = "restaurant_image")val image_url:String
)