package database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface RestaurantDao {
@Insert
    fun insertRestaurant(restaurantEntity: Entities)
    @Delete
    fun deleteRestaurant(restaurantEntity: Entities)
    @Query("SELECT * FROM restaurants" )
    fun getAllRestaurants(): List<Entities>
@Query("SELECT * FROM restaurants WHERE id=:restaurantId")
    fun getRestaurantById(restaurantId:String):Entities

}