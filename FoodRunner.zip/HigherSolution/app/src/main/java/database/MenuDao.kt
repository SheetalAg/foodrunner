package database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
@Dao
interface MenuDao {
    @Insert
    fun insertOrder(menuEntity: MenuEntity)

    @Delete
    fun deleteOrder(menuEntity: MenuEntity)

    @Query("SELECT * FROM menu")
    fun getAllOrders(): List<MenuEntity>

    @Query("DELETE FROM menu WHERE resId = :resId")
    fun deleteOrders(resId: String)
}