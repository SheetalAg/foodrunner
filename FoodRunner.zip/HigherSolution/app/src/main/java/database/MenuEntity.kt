package database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "menu")
data class MenuEntity(
    @PrimaryKey() val resId:Int,
    @ColumnInfo(name="food_items") val foodItems:String
)